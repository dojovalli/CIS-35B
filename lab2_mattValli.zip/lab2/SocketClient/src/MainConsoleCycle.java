
public class MainConsoleCycle {
	// Console LifeCycle
	public static void main(String[] args) {
		ConsoleController console = new ClientController();
		console.onCreate();
	}
}
