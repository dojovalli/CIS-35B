
public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// Create a new ConsoleController
		ConsoleController console = new ConsoleController();
		
		// Call the 'onCreate()' method to handle running the program
		console.onCreate();
	}

}
